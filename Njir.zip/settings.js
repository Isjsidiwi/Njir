// 𝗖𝗢𝗡𝗧𝗥𝗢𝗟 𝗕𝗢𝗧 

global.prefa = ['','!','.',',','🐤','🗿'] //NOT CHANGE
global.owner = ['6282286487441'] //OWNER
global.botname = 'SKYTZY 5.0.0' //BOT NAME
global.baileys1 = require('@whiskeysockets/baileys') //NOT CHANGE
global.creator = "SKYTZY DEV" //NOT CHANGE
global.packname = "Sticker By" //OPSIONAL
global.author = "SKYTZY" //OPSIONAL
global.idCH = "12036332178034299@newsletter" // OPSIONAL